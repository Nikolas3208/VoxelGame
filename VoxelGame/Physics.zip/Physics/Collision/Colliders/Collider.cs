﻿using SFML.System;

namespace VoxelGame.Physics.Collision.Colliders
{
    /// <summary>
    /// Тип коллайдера
    /// </summary>
    public enum ColliderType
    {
        Circle,
        Poligon
    }

    public abstract class Collider
    {
        /// <summary>
        /// Тип коллайдера
        /// </summary>
        public ColliderType Type { get; set; }

        /// <summary>
        /// Ссылка на тело
        /// </summary>
        public RigidBody? Body { get; set; }

        /// <summary>
        /// Коллайдер
        /// </summary>
        public Collider(ColliderType type)
        {
            Type = type;
        }

        public float GetRadius()
        {
            if (this is Circle circle)
            {
                return circle.Radius;
            }
            return 0;
        }

        public Vector2f[] GetVertices()
        {
            if (this is Polygon polygon)
            {
                return polygon.GetVertices();
            }
            return new Vector2f[0];
        }

        /// <summary>
        /// Обновление трансформации коллайдера
        /// </summary>
        /// <param name="position"> Новая позиция </param>
        /// <returns></returns>
        public abstract Collider Transform(Vector2f position);

        /// <summary>
        /// Обновление трансформации коллайдера с учетом вращения
        /// </summary>
        /// <param name="sin"> Новый угол, синус </param>
        /// <param name="cos"> Новый угол, косинус </param>
        /// <param name="position"> Новая позиция </param>
        /// <returns></returns>
        public abstract Collider Transform(float sin, float cos, Vector2f position);

        /// <summary>
        /// Получить массу коллайдера
        /// </summary>
        /// <param name="density"> Плотность </param>
        /// <returns> Float </returns>
        public abstract float GetMass(float density);

        /// <summary>
        /// Получить инерцию коллайдера
        /// </summary>
        /// <param name="density"> Плотность </param>
        /// <returns></returns>
        public abstract float GetInertia(float density);

        /// <summary>
        /// Получить размер коллайдера
        /// </summary>
        /// <returns></returns>
        public abstract Vector2f GetSize();

        /// <summary>
        /// Получить центр коллайдера
        /// </summary>
        /// <returns></returns>
        public abstract Vector2f GetCenter();
    }
}
